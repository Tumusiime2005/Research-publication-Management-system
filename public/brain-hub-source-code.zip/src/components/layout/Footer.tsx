import React from 'react';
import { Download } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-200 mt-auto py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2.5 flex-wrap">
            <img 
              src="/assets/aistudio/image_c3fb1387_fb406a7b.jpg" 
              alt="BRAIN HUB Icon" 
              className="w-5 h-5 object-contain rounded"
            />
            <span className="font-bold text-[#1E1B4B] tracking-tight">BRAIN HUB</span>
            <span>·</span>
            <span>Open Research Publication Management System</span>
            <span>·</span>
            <a
              href="/brain-hub-source-code.zip"
              download="brain-hub-source-code.zip"
              className="inline-flex items-center gap-1 font-semibold text-[#6D28D9] hover:text-[#5B21B6] hover:underline transition-colors"
              title="Download entire system source code (.zip) for offline development"
            >
              <Download className="w-3.5 h-3.5" />
              Download Offline Package (.ZIP)
            </a>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-1.5 sm:gap-3 text-xs">
            <span className="font-bold text-[#6D28D9] tracking-wide">
              MARON PRIME THE LEGENDARY SYSTEMS ANALYST
            </span>
            <span className="hidden sm:inline text-slate-300">·</span>
            <span className="font-mono font-semibold text-slate-700 tabular-nums">
              +256 769849051
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
